import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { http } from '@/shared/api/http';
import { endpoints } from '@/shared/api/endpoints';
import { isSelf } from '@/shared/auth/isSelf';

import Header from '@/shared/ui/SiteHeader';
import Footer from '@/shared/ui/SiteFooter';

type PublicUser = { id: string; username: string; about?: string; avatar?: string };
type Me = PublicUser & { email?: string };
type Stats = { servers?: number; sessions?: number; achievements?: number; registeredAt?: string; online?: boolean };

export default function UserProfilePage() {
  const username = useParams().username!;
  const self = isSelf(username);

  const [user, setUser] = useState<PublicUser | Me | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setErr(null);

    const req = self ? http.get<Me>(endpoints.profileMe) : http.get<PublicUser>(endpoints.userByName(username));

    req
      .then(({ data }) => {
        if (!alive) return;
        setUser(data);
        setStats((s) => s ?? { servers: 3, sessions: 128, achievements: 16, registeredAt: '2024-10-01T12:34:56Z', online: true });
      })
      .catch((e) => alive && setErr(e?.response?.data?.message || e?.message || 'Ошибка загрузки'))
      .finally(() => alive && setLoading(false));

    return () => {
      alive = false;
    };
  }, [username, self]);

  const since = useMemo(() => {
    const iso = stats?.registeredAt;
    if (!iso) return null;
    try { return new Date(iso).toLocaleDateString(); } catch { return null; }
  }, [stats?.registeredAt]);

  return (
    <div className="min-h-dvh bg-slate-950 text-slate-100 flex flex-col">
      <Header />

      {/* Шапка страницы в фирменном синем */}
      <div className="border-b border-slate-800 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <div className="text-sm font-medium tracking-wide text-sky-400">Профиль</div>
          <div className="flex items-center gap-2">
            {!self && (
              <button className="rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500">
                Сообщение
              </button>
            )}
            <button
              className={`rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-sky-300 ${
                self
                  ? 'border border-slate-700 hover:border-slate-500'
                  : 'bg-sky-600 hover:bg-sky-500'
              }`}
            >
              {self ? 'Редактировать' : 'Подписаться'}
            </button>
          </div>
        </div>
      </div>

      {/* Контент */}
      <main className="mx-auto grid w-full max-w-6xl grow grid-cols-12 gap-6 px-4 py-6">
        {/* Левый сайдбар: 3D-с kin */}
        <section className="col-span-12 md:col-span-3">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold">Скин</h2>
              <div className="text-xs text-slate-400">3D</div>
            </div>
            <div
              aria-label="3D-просмотр скина"
              className="aspect-3/4 w-full rounded-xl border border-slate-800 bg-slate-900"
            />
            <div className="mt-3 flex gap-2">
              <button className="grow rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500">
                Повернуть
              </button>
              <button className="grow rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500">
                {self ? 'Заменить' : 'Скачать'}
              </button>
            </div>
          </Card>
        </section>

        {/* Центральная колонка */}
        <section className="col-span-12 md:col-span-9">
          <Card className="relative overflow-visible">
            {/* Аватар перекрывает карточку */}
            <div className="pointer-events-none absolute -top-12 left-1/2 -translate-x-1/2">
              <Avatar url={(user as any)?.avatar} loading={loading} />
            </div>

            <div className="pt-14 text-center">
              <div className="mb-1 flex items-center justify-center gap-2">
                <h1 className="truncate text-2xl font-bold">
                  {loading ? 'Загрузка…' : user ? `@${user.username}` : '—'}
                </h1>
                {stats?.online != null && (
                  <span
                    className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${
                      stats.online ? 'border-green-700 text-green-400' : 'border-slate-700 text-slate-400'
                    }`}
                    title={stats.online ? 'Онлайн' : 'Оффлайн'}
                  >
                    <span className={`h-2 w-2 rounded-full ${stats.online ? 'bg-green-500' : 'bg-slate-500'}`} />
                    {stats.online ? 'online' : 'offline'}
                  </span>
                )}
              </div>

              <div className="mb-4 text-xs text-slate-400">
                {since && <span>с {since}</span>}
                {self && <span className="ml-2 rounded-md border border-slate-700 px-2 py-0.5 text-sky-400">это вы</span>}
              </div>

              <p className="mx-auto max-w-2xl whitespace-pre-wrap text-sm text-slate-200">
                {loading ? '…' : user?.about || 'Описание не заполнено'}
              </p>

              <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
                {self ? (
                  <>
                    <a
                      href="/settings/profile"
                      className="rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500"
                    >
                      Настройки
                    </a>
                    <button className="rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500">
                      Поделиться
                    </button>
                  </>
                ) : (
                  <>
                    <button className="rounded-xl border border-slate-700 px-3 py-1.5 text-sm hover:border-slate-500">
                      Написать
                    </button>
                    <button className="rounded-xl border border-red-800 px-3 py-1.5 text-sm text-red-400 hover:bg-red-900/20">
                      Пожаловаться
                    </button>
                  </>
                )}
              </div>

              <div className="mt-6 grid grid-cols-3 gap-2 text-center text-sm">
                <Stat label="Сервера" value={stats?.servers} loading={loading} />
                <Stat label="Сессии" value={stats?.sessions} loading={loading} />
                <Stat label="Ачивки" value={stats?.achievements} loading={loading} />
              </div>
            </div>
          </Card>

          {/* Доп. блоки */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Card>
              <h3 className="mb-3 text-sm font-semibold text-sky-300">Достижения</h3>
              <Empty loading={loading} text="Нет достижений" />
            </Card>
            <Card>
              <h3 className="mb-3 text-sm font-semibold text-sky-300">Недавние сессии</h3>
              <Empty loading={loading} text="Нет данных" />
            </Card>
          </div>

          {err && (
            <div className="mt-6 rounded-xl border border-red-800 bg-red-950/40 p-3 text-sm text-red-300">
              {err}
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}

/* ===== UI helpers (в стиле проекта, с синим акцентом) ===== */

function Card(props: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={`rounded-2xl border border-slate-800 bg-slate-900/60 p-4 shadow-[0_1px_0_#ffffff10_inset,0_20px_40px_-20px_#000] ${props.className || ''}`}
    >
      {props.children}
    </section>
  );
}

function Avatar({ url, loading }: { url?: string; loading: boolean }) {
  return (
    <div className="h-32 w-32 rounded-3xl border-2 border-sky-700/50 bg-slate-900 shadow-[0_8px_24px_rgba(2,132,199,0.25)]">
      {loading ? (
        <div className="h-full w-full animate-pulse rounded-3xl bg-slate-800" />
      ) : url ? (
        // eslint-disable-next-line jsx-a11y/alt-text
        <img src={url} alt="Аватар" className="h-full w-full rounded-3xl object-cover" loading="lazy" />
      ) : (
        <div className="flex h-full w-full items-center justify-center rounded-3xl text-slate-400">AVA</div>
      )}
    </div>
  );
}

function Stat({ label, value, loading }: { label: string; value?: number; loading: boolean }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-3">
      <div className="text-lg font-semibold text-sky-300">{loading ? '…' : value ?? 0}</div>
      <div className="text-xs text-slate-400">{label}</div>
    </div>
  );
}

function Empty({ loading, text }: { loading: boolean; text: string }) {
  return loading ? (
    <div className="h-20 animate-pulse rounded-xl bg-slate-800" />
  ) : (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-center text-sm text-slate-400">{text}</div>
  );
}
