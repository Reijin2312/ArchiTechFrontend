import { authStore, type User } from '@/shared/store/auth';
import { endpoints } from '@/shared/api/endpoints';
import { http } from '@/shared/api/http';

export async function bootstrapAuth() {
  try {
    // 1) попытка refresh по HttpOnly-cookie
    const r = await fetch(endpoints.refresh, { method: 'POST', credentials: 'include' });
    if (!r.ok) return; // не залогинен — ничего
    const { accessToken } = await r.json();

    // 2) кладём access и тянем профиль
    authStore.getState().setAuth(null, accessToken);
    const me = await http.get<User>('/api/v1/profile/me');
    authStore.getState().setAuth(me.data, accessToken);
  } catch {
    authStore.getState().clear();
  }
}
