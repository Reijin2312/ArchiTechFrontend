import { authStore, type User } from '@/shared/store/auth';
import { http } from '@/shared/api/http';

export async function finalizeAuth(accessToken: string) {
  authStore.getState().setAuth(null, accessToken);
  const me = await http.get<User>('/api/v1/profile/me');
  authStore.getState().setAuth(me.data, accessToken);
}
